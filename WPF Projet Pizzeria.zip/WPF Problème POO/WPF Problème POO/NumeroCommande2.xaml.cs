﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour NumeroCommande2.xaml
    /// </summary>
    public partial class NumeroCommande2 : Window
    {
        ClasseCommande c1 = new ClasseCommande();
        ClasseCommande c2 = new ClasseCommande();

        public NumeroCommande2()
        {
            InitializeComponent();
        }

        private void PrixCommande(object sender, RoutedEventArgs e)
        {
            c1.NumCommande = NumeroDeCommande2.Text;

            c2 = c2.TrouverCommande(c1.NumCommande);

            this.Close();

            if (c2 != null)
            {
                MessageBox.Show(c2.Solde, "Solde commande");
            }
        }
    }
}
