﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour Statistiques.xaml
    /// </summary>
    public partial class Statistiques : Window
    {
        public Statistiques()
        {
            InitializeComponent();
        }

        private void CommandesGereesCommis(object sender, RoutedEventArgs e)
        {


            MessageBox.Show("Commis : Jean Eude - Nombre de commandes gérées : 2 \nCommis : Didier Jacques - Nombre de commandes gérées : 6 \nCommis : Mike Down - Nombre de commandes gérées : 1");
        }

        private void CommandesGereesLivreur(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Livreur : Max Lot - Nombre de livraisons effectuées : 2 \nLivreur : James Lot - Nombre de livraisons effectuées : 4 \nLivreur : Thibaud Bloom - Nombre de livraisons effectuées : 3 ");
        }

        private void CommandesPeriodeTemps(object sender, RoutedEventArgs e)
        {
            CommandesPeriode c = new CommandesPeriode();

            c.Show();
        }

        private void MoyennePrix(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Moyenne des prix : 16 euros");
        }

        private void MoyenneClients(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Moyenne des dépenses des clients : 12 euros");
        }

        private void RetourMenu(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
