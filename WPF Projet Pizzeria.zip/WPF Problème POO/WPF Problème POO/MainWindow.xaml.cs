﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CreerCommande(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Nouveau Client ?", "Création commande", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                CreationClient1 c = new CreationClient1();

                c.Show();
            }
            else
            {
                NumeroTelephone n = new NumeroTelephone();

                n.Show();
            }
        }

        private void MenuClients(object sender, RoutedEventArgs e)
        {
            Clients cl = new Clients();

            cl.Show();
        }

        private void MenuCommis(object sender, RoutedEventArgs e)
        {
            Commis co = new Commis();

            co.Show();
        }

        private void MenuLivreur(object sender, RoutedEventArgs e)
        {
            Livreurs li = new Livreurs();

            li.Show();
        }

        private void MenuCommandes(object sender, RoutedEventArgs e)
        {
            Commandes com = new Commandes();

            com.Show();
        }

        private void MenuStatistiques(object sender, RoutedEventArgs e)
        {
            Statistiques stat = new Statistiques();

            stat.Show();
        }

        private void MenuAutre(object sender, RoutedEventArgs e)
        {
            Autre a = new Autre();

            a.Show();
        }
    }
}
