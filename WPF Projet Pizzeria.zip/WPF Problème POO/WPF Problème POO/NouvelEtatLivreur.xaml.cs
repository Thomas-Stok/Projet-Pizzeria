﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour NouvelEtatLivreur.xaml
    /// </summary>
    public partial class NouvelEtatLivreur : Window
    {
        ClasseLivreur c = new ClasseLivreur();
        public NouvelEtatLivreur(ClasseLivreur c)
        {
            InitializeComponent();

            this.c = c;
        }

        private void EtatChange(object sender, RoutedEventArgs e)
        {
            c.Etat = EtatLivreur.Text;

            this.Close();
            
            MessageBox.Show("Etat du livreur changé");
        }
    }
}
