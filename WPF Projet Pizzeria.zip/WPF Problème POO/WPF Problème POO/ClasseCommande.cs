﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace WPF_Problème_POO
{
    public class ClasseCommande : INotifyPropertyChanged
    {
        string numCommande;
        string heure;
        string dateCommande;
        string numClient;
        string nomCommis;
        string nomLivreur;
        string etat;
        string solde;
        string derniernumCommande;
        string prix;
        public event PropertyChangedEventHandler PropertyChanged;

        public ClasseCommande(string numCommande, string heure, string dateCommande, string numClient, string nomCommis, string nomLivreur, string etat, string solde)
        {
            this.numCommande = numCommande;
            this.heure = heure;
            this.dateCommande = dateCommande;
            this.numClient = numClient;
            this.nomCommis = nomCommis;
            this.nomLivreur = nomLivreur;
            this.etat = etat;
            this.solde = solde;
            this.derniernumCommande = "0";
        }

        public ClasseCommande()
        {

        }

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        public string NumCommande
        {
            get { return this.numCommande; }
            set { this.numCommande = value; OnPropertyChanged("NumCommande"); }
        }

        public string Heure
        {
            get { return this.heure; }
        }

        public string DateCommande
        {
            get { return this.dateCommande; }
        }

        public string NumClient
        {
            get { return this.numClient; }
        }

        public string NomCommis
        {
            get { return this.nomCommis; }
        }

        public string NomLivreur
        {
            get { return this.nomLivreur; }
        }

        public string Etat
        {
            get { return this.etat; }
            set { this.etat = value; }
        }

        public string Solde
        {
            get { return this.solde; }
            set { this.solde = value; }
        }

        public string Prix
        {
            get { return this.prix; }
            set { this.prix = value; }
        }

        public List<ClasseCommande> LectureFichier()
        {
            List<ClasseCommande> commandes = null;
            StreamReader st = null;

            int dernier = 0;

            try
            {
                commandes = new List<ClasseCommande>();
                st = new StreamReader("Commandes.csv");
                string line = null;
                while ((line = st.ReadLine()) != null)
                {
                    string[] c = line.Split(';');
                    ClasseCommande commandeTemp = new ClasseCommande(c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7]);
                    commandes.Add(commandeTemp);
                    dernier = Convert.ToInt32(c[0]);
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            { if (st != null) st.Close(); }

            derniernumCommande = Convert.ToString(dernier + 1);
            return commandes;
        }

        public void AjouterCommande(ClasseCommande commande)
        {
            StreamWriter fichEcriture = new StreamWriter("Commandes.csv", true);
            string ligne = commande.NumCommande + ";" + commande.Heure + ";" + commande.DateCommande + ";" + commande.NumClient + ";" + commande.NomCommis + ";" + commande.NomLivreur + ";" + commande.Etat + ";" + commande.Solde;
            fichEcriture.WriteLine(ligne);
            fichEcriture.Close();
        }

        public override string ToString()
        {
            return " Num de commande : " + NumCommande + " - Heure : " + Heure + " - Date : " + DateCommande + " - Téléphone du client : " + NumClient + " - Nom du commis : " + NomCommis + " - Nom du livreur : " + NomLivreur + " - état de la commande : " + Etat + " - " + Solde; ;
        }

        public ClasseCommande TrouverCommande(string numCommande)
        {
            ClasseCommande commande = new ClasseCommande();
            commande = null;

            List<ClasseCommande> commandes = LectureFichier();

            foreach (ClasseCommande c in commandes)
            {
                if (c.NumCommande == numCommande)
                {
                    commande = c;
                }
            }

            return commande;
        }

        public ClasseLivreur ChoixLivreur()
        {
            ClasseLivreur l = new ClasseLivreur();
            List<ClasseLivreur> livreurs = l.LectureFichier();
            List<ClasseLivreur> livreursSurPlace = new List<ClasseLivreur>();

            foreach (ClasseLivreur l1 in livreurs)
            {
                if (l1.Etat == "Sur place")
                {
                    livreursSurPlace.Add(l1);
                }
            }

            Random rand = new Random();
            int aleatoire = rand.Next(livreursSurPlace.Count);
            ClasseLivreur choisi = new ClasseLivreur();
            int compt = 0;

            foreach (ClasseLivreur l2 in livreursSurPlace)
            {
                if (compt == aleatoire)
                {
                    choisi = l2;
                }
                compt++;
            }

            return choisi;
        }

        public void CreerCommande(string numClient, string nomCommis, ClasseLivreur choisi)
        {
            ClasseLivreur livreurChoisi = choisi;

            LectureFichier();
            ClasseCommande commande = new ClasseCommande(derniernumCommande, DateTime.Now.Hour.ToString(), DateTime.Now.Date.ToShortDateString(), numClient, nomCommis, livreurChoisi.Nom, "ouvert", solde);
            AjouterCommande(commande);
        }

        public void CreerCommandeEnPreparation(string numClient, string nomCommis, ClasseLivreur choisi)
        {
            ClasseLivreur livreurChoisi = choisi;

            LectureFichier();
            ClasseCommande commande = new ClasseCommande(derniernumCommande, DateTime.Now.Hour.ToString(), DateTime.Now.Date.ToShortDateString(), numClient, nomCommis, livreurChoisi.Nom, "en preparation", solde);
            AjouterCommande(commande);
        }

        public void FinaliserCommande(string adresse_trouvee, ClasseLivreur livreur, string prixTotal, ClasseCommande commande)
        {
            ClasseClient c = new ClasseClient();

            if (adresse_trouvee == "ok")
            {
                commande.Etat = "Fermee";
                commande.Solde = "ok";
                AjouterCommande(commande);
                List<ClasseClient> c1 = c.LectureFichier();
                foreach (ClasseClient cl in c1)
                {
                    if (cl.Tel == commande.NumClient)
                    {
                        c = cl;
                    }
                }
                int p = Convert.ToInt32(prixTotal);
                int m = Convert.ToInt32(c.MontantTotal);
                m += p;
                prixTotal = Convert.ToString(p);
                c.MontantTotal = Convert.ToString(m);

                int cumul = Convert.ToInt32(c.NbCommandes);
                cumul++;
                c.NbCommandes = Convert.ToString(cumul);
                c.AjouterClient(c);
            }
            else
            {
                commande.Etat = "Fermee";
                commande.Solde = "perdue";
                AjouterCommande(commande);
            }
        }

        public void RecupererEtat(ClasseCommande c)
        {
            Console.WriteLine(c.Etat);
        }
    }
}
