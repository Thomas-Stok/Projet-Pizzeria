﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour CreationLivreur2.xaml
    /// </summary>
    public partial class CreationLivreur2 : Window
    {
        ClasseLivreur c1 = new ClasseLivreur();
        ClasseLivreur c2 = new ClasseLivreur();

        public CreationLivreur2(string nomDeLivreur)
        {
            InitializeComponent();

            c1 = c1.TrouverLivreur(nomDeLivreur);

            NomCreationLivreur2.Text = c1.Nom;
            PrenomCreationLivreur2.Text = c1.Prenom;
            RueCreationLivreur2.Text = c1.AdresseRue;
            VilleCreationLivreur2.Text = c1.AdresseVille;
            TelephoneCreationLivreur2.Text = c1.Tel;
            EtatCreationLivreur2.Text = c1.Etat;
            TransportCreationLivreur2.Text = c1.MoyenTransport;
        }

        private void VersMenuLivreur(object sender, RoutedEventArgs e)
        {
            c2.Nom = NomCreationLivreur2.Text;
            c2.Prenom = PrenomCreationLivreur2.Text;
            c2.AdresseRue = RueCreationLivreur2.Text;
            c2.AdresseVille = VilleCreationLivreur2.Text;
            c2.Tel = TelephoneCreationLivreur2.Text;
            c2.Etat = EtatCreationLivreur2.Text;
            c2.MoyenTransport = TransportCreationLivreur2.Text;
            c2.NbLivraisonsEffectuees = c1.NbLivraisonsEffectuees;

            MessageBox.Show(c2.ToString());

            c2.ModifierLivreur(c2);

            this.Close();
        }
    }
}
