﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace WPF_Problème_POO
{
    public class ClasseLivreur : ClassePersonne, INotifyPropertyChanged
    {
        string etat;
        string moyenTransport;
        string nbLivraisonsEffectuees;

        public ClasseLivreur(string nom, string prenom, string adresse_rue, string adresse_ville, string tel, string etat, string moyenTransport, string nbLivraisonsEffectuees) : base(nom, prenom, adresse_rue, adresse_ville, tel)
        {
            this.etat = etat;
            this.moyenTransport = moyenTransport;
            this.nbLivraisonsEffectuees = nbLivraisonsEffectuees;
        }

        public ClasseLivreur()
        {

        }

        public string Etat
        {
            get { return this.etat; }
            set { this.etat = value; OnPropertyChanged("Etat"); }
        }

        public string MoyenTransport
        {
            get { return this.moyenTransport; }
            set { this.moyenTransport = value; OnPropertyChanged("MoyenTransport"); }
        }

        public string NbLivraisonsEffectuees
        {
            get { return this.nbLivraisonsEffectuees; }
            set { this.nbLivraisonsEffectuees = value; }
        }

        public override string ToString()
        {
            return base.ToString() + " - état : " + this.etat + " - moyen de transport : " + this.moyenTransport;
        }

        public int Compare3(ClasseLivreur c1, ClasseLivreur c2)
        {
            return c1.NbLivraisonsEffectuees.CompareTo(c2.NbLivraisonsEffectuees);
        }

        public string AdresseTrouvee()
        {
            string trouvee = "ok";
            
            Random rand = new Random();

            int aleatoire = rand.Next(20);

            if (aleatoire == 0)
                trouvee = "perdue";

            return trouvee;
        }

        public List<ClasseLivreur> LectureFichier()
        {
            List<ClasseLivreur> livreurs = null;
            StreamReader st = null;

            try
            {
                livreurs = new List<ClasseLivreur>();
                st = new StreamReader("Livreur.csv");
                string line = null;
                while ((line = st.ReadLine()) != null)
                {
                    string[] c = line.Split(';');
                    ClasseLivreur livreurTemp = new ClasseLivreur(c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7]);
                    livreurs.Add(livreurTemp);
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            { if (st != null) st.Close(); }

            return livreurs;
        }

        public ClasseLivreur TrouverLivreur(string nom)
        {
            ClasseLivreur livreur = new ClasseLivreur();
            livreur = null;

            List<ClasseLivreur> livreurs = LectureFichier();

            foreach (ClasseLivreur c in livreurs)
            {
                if (c.Nom == nom)
                {
                    livreur = c;
                }
            }

            return livreur;
        }

        public void ModifierLivreur(ClasseLivreur livreur)
        {
            StreamWriter fichEcriture = new StreamWriter("Livreur.csv", true);
            string ligne = livreur.Nom + ";" + livreur.Prenom + ";" + livreur.AdresseRue + ";" + livreur.AdresseVille + ";" + livreur.Tel + ";" + livreur.Etat + ";" + livreur.MoyenTransport + ";" + livreur.NbLivraisonsEffectuees;
            fichEcriture.WriteLine(ligne);
            fichEcriture.Close();
        }
    }
}
