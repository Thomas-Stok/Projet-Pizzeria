﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour CréationClient3.xaml
    /// </summary>
    public partial class CreationClient3 : Window
    {
        ClasseClient c = new ClasseClient();

        public CreationClient3()
        {
            InitializeComponent();
        }

        private void VersMenuClient(object sender, RoutedEventArgs e)
        {
            c.Nom = NomCreationClient3.Text;
            c.Prenom = PrenomCreationClient3.Text;
            c.AdresseRue = RueCreationClient3.Text;
            c.AdresseVille = VilleCreationClient3.Text;
            c.Tel = TelephoneCreationClient3.Text;
            c.Date_premiere_commande = DateTime.Today.ToShortDateString();
            c.NbCommandes = "0";
            c.MontantTotal = "0";

            MessageBox.Show(c.ToString());

            c.AjouterClient(c);

            this.Close();
        }
    }
}
