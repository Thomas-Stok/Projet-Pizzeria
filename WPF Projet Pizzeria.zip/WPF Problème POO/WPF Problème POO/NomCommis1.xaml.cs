﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour NomCommis.xaml
    /// </summary>
    public partial class NomCommis1 : Window
    {
        ClasseCommis c1 = new ClasseCommis();
        ClasseCommis c2 = new ClasseCommis();

        public NomCommis1()
        {
            InitializeComponent();
        }

        private void NouvelEtat(object sender, RoutedEventArgs e)
        {
            c1.Nom = NomDuCommis1.Text;

            c2 = c2.TrouverCommis(c1.Nom);

            if (c2 != null)
            {
                CreationCommis2 n = new CreationCommis2(c1.Nom);

                n.Show();
            }

            this.Close();
        }
    }
}
