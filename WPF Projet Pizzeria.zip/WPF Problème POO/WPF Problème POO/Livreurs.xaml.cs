﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour Livreurs.xaml
    /// </summary>
    public partial class Livreurs : Window
    {
        public Livreurs()
        {
            InitializeComponent();
        }

        private void NouveauLivreur(object sender, RoutedEventArgs e)
        {
            CreationLivreur1 l1 = new CreationLivreur1();

            l1.Show();
        }

        private void ModifierLivreur(object sender, RoutedEventArgs e)
        {
            NomLivreur1 n1 = new NomLivreur1();

            n1.Show();
        }

        private void ModifierEtatLivreur(object sender, RoutedEventArgs e)
        {
            NomLivreur3 n3 = new NomLivreur3();

            n3.Show();
        }

        private void SupprimerLivreur(object sender, RoutedEventArgs e)
        {
            NomLivreur2 n2 = new NomLivreur2();

            n2.Show();
        }

        private void AfficherLivreurs(object sender, RoutedEventArgs e)
        {
            AfficherLivreurs a = new AfficherLivreurs();

            a.Show();
        }

        private void RetourMenu(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
