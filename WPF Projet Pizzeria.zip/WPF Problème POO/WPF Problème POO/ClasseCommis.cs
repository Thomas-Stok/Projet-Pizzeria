﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace WPF_Problème_POO
{
    public class ClasseCommis : ClassePersonne, IEmploye, INotifyPropertyChanged
    {
        string etat;
        string dateEmbauche;
        string nbCommandesGerees;

        public ClasseCommis(string nom, string prenom, string adresse_rue, string adresse_ville, string tel, string etat, string dateEmbauche, string nbCommandesGerees) : base(nom, prenom, adresse_rue, adresse_ville, tel)
        {
            this.etat = etat;
            this.dateEmbauche = dateEmbauche;
            this.nbCommandesGerees = nbCommandesGerees;
        }

        public ClasseCommis()
        {

        }

        public string Etat
        {
            get { return this.etat; }
            set { this.etat = value; OnPropertyChanged("Etat"); }
        }

        public string DateEmbauche
        {
            get { return this.dateEmbauche; }
            set { this.dateEmbauche = value; OnPropertyChanged("DateEmbauche"); }
        }

        public string NbCommandesGerees
        {
            get { return this.nbCommandesGerees; }
            set { this.nbCommandesGerees = value; }
        }

        public List<ClasseCommis> LectureFichier()
        {
            List<ClasseCommis> comm = null;
            StreamReader st = null;

            try
            {
                comm = new List<ClasseCommis>();
                st = new StreamReader("Commis.csv");
                string line = null;
                while ((line = st.ReadLine()) != null)
                {
                    string[] c = line.Split(';');
                    ClasseCommis commisTemp = new ClasseCommis(c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7]);
                    comm.Add(commisTemp);
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            { if (st != null) st.Close(); }

            return comm;
        }

        public int Compare3(ClasseCommis c1, ClasseCommis c2)
        {
            return c1.NbCommandesGerees.CompareTo(c2.NbCommandesGerees);
        }

        public ClasseCommis TrouverCommis(string nom)
        {
            ClasseCommis commis = new ClasseCommis();
            commis = null;

            List<ClasseCommis> listeCommis = LectureFichier();

            foreach (ClasseCommis c in listeCommis)
            {
                if (c.Nom == nom)
                {
                    commis = c;
                }
            }

            return commis;
        }

        public void ModifierCommis(ClasseCommis commis)
        {
            StreamWriter fichEcriture = new StreamWriter("Commis.csv", true);
            string ligne = commis.Nom + ";" + commis.Prenom + ";" + commis.AdresseRue + ";" + commis.AdresseVille + ";" + commis.Tel + ";" + commis.Etat + ";" + commis.DateEmbauche + ";" + commis.NbCommandesGerees;
            fichEcriture.WriteLine(ligne);
            fichEcriture.Close();
        }

        public void MofifierEtatCommis()
        {
            string rep = "";
            string tel = "";

            Console.Write("Souhaitez-vous déclarer un congé ou un retour ? ");
            rep = Console.ReadLine();
            Console.WriteLine("Veuillez saisir le numéro du commis concerné");
            tel = Console.ReadLine();
            ClasseCommis commis = new ClasseCommis();
            List<ClasseCommis> comm = LectureFichier();
            foreach (ClasseCommis c in comm)
            {
                if (c.Tel == tel)
                {
                    commis = c;
                }
            }
            if (rep == "congé")
            {
                commis.Etat = "En conges";
                ModifierCommis(commis);
            }
            else if (rep == "retour")
            {
                commis.Etat = "Sur place";
                ModifierCommis(commis);
            }

        }

        public void MofifierEtatLivreur()
        {
            string rep = "";
            string tel = "";

            Console.Write("Souhaitez-vous déclarer un congé ou un retour ? ");
            rep = Console.ReadLine();
            Console.WriteLine("Veuillez saisir le numéro du livreur concerné");
            tel = Console.ReadLine();
            ClasseLivreur livreur = new ClasseLivreur();
            List<ClasseLivreur> livreurs = livreur.LectureFichier();
            foreach (ClasseLivreur l in livreurs)
            {
                if (l.Tel == tel)
                {
                    livreur = l;
                }
            }
            if (rep == "congé")
            {
                livreur.Etat = "En conges";
                livreur.ModifierLivreur(livreur);
            }
            else if (rep == "retour")
            {
                livreur.Etat = "Sur place";
                livreur.ModifierLivreur(livreur);
            }
        }
        public string RecupererEtat()
        {
            return "";
        }

        public override string ToString()
        {
            return base.ToString() + " - état : " + Etat + " - date d'embauche : " + this.dateEmbauche;
        }

    }
}
