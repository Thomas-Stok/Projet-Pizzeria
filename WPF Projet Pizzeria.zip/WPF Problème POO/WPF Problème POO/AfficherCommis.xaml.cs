﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour AfficherCommis.xaml
    /// </summary>
    public partial class AfficherCommis : Window
    {
        string affichage;

        public AfficherCommis()
        {
            InitializeComponent();
        }

        private void AfficherLesCommis(object sender, RoutedEventArgs e)
        {
            this.Close();

            if (RadioButton1Commis.IsChecked == true)
            {
                ClasseCommis commis1 = new ClasseCommis();

                List<ClasseCommis> listeCommis1 = new List<ClasseCommis>();
                listeCommis1 = commis1.LectureFichier();

                listeCommis1.Sort(commis1.Compare);
                listeCommis1.ForEach(x => affichage += x.ToString() + "\n");

                MessageBox.Show(affichage);
            }
            else if (RadioButton2Commis.IsChecked == true)
            {
                ClasseCommis commis2 = new ClasseCommis();

                List<ClasseCommis> listeCommis2 = new List<ClasseCommis>();
                listeCommis2 = commis2.LectureFichier();

                listeCommis2.Sort(commis2.Compare2);
                listeCommis2.ForEach(x => affichage += x.ToString() + "\n");

                MessageBox.Show(affichage);
            }
            else if (RadioButton3Commis.IsChecked == true)
            {
                ClasseCommis commis3 = new ClasseCommis();

                List<ClasseCommis> listeCommis3 = new List<ClasseCommis>();
                listeCommis3 = commis3.LectureFichier();

                listeCommis3.Sort(commis3.Compare3);
                listeCommis3.ForEach(x => affichage += x.ToString() + "\n");

                MessageBox.Show(affichage);
            }
        }
    }
}
