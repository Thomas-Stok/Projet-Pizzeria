﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour NomLivreur3.xaml
    /// </summary>
    public partial class NomLivreur3 : Window
    {
        ClasseLivreur c1 = new ClasseLivreur();
        ClasseLivreur c2 = new ClasseLivreur();

        string etat;

        public NomLivreur3()
        {
            InitializeComponent();
        }

        private void ModifierEtatLivreur(object sender, RoutedEventArgs e)
        {
            c1.Nom = NomDuLivreur2.Text;

            c2 = c2.TrouverLivreur(c1.Nom);

            etat = c2.Etat;

            this.Close();

            if (c2 != null)
            {
                if (etat == "En conges")
                    c2.Etat = "Sur place";
                else if (etat == "Sur place")
                    c2.Etat = "En conges";

                c2.ModifierLivreur(c2);

                MessageBox.Show("Nouvel état : " + c2.Etat);
            }
        }
    }
}
