﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour AfficherLivreur.xaml
    /// </summary>
    public partial class AfficherLivreurs : Window
    {
        string affichage;

        public AfficherLivreurs()
        {
            InitializeComponent();
        }

        private void AfficherLesLivreurs(object sender, RoutedEventArgs e)
        {
            this.Close();

            if (RadioButton1Livreurs.IsChecked == true)
            {
                ClasseLivreur livreur1 = new ClasseLivreur();

                List<ClasseLivreur> livreurs1 = new List<ClasseLivreur>();
                livreurs1 = livreur1.LectureFichier();

                livreurs1.Sort(livreur1.Compare);
                livreurs1.ForEach(x => affichage += x.ToString() + "\n");

                MessageBox.Show(affichage);
            }
            else if (RadioButton2Livreurs.IsChecked == true)
            {
                ClasseLivreur livreur2 = new ClasseLivreur();

                List<ClasseLivreur> livreurs2 = new List<ClasseLivreur>();
                livreurs2 = livreur2.LectureFichier();

                livreurs2.Sort(livreur2.Compare2);
                livreurs2.ForEach(x => affichage += x.ToString() + "\n");

                MessageBox.Show(affichage);
            }
            else if (RadioButton3Livreurs.IsChecked == true)
            {
                ClasseLivreur livreur3 = new ClasseLivreur();

                List<ClasseLivreur> livreurs3 = new List<ClasseLivreur>();
                livreurs3 = livreur3.LectureFichier();

                livreurs3.Sort(livreur3.Compare3);
                livreurs3.ForEach(x => affichage += x.ToString() + "\n");

                MessageBox.Show(affichage);
            }
        }
    }
}
