﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour NuméroTéléphone.xaml
    /// </summary>
    public partial class NumeroTelephone : Window
    {
        ClasseClient c1 = new ClasseClient();
        ClasseClient c2 = new ClasseClient();

        string tel = "";

        public NumeroTelephone()
        {
            InitializeComponent();
        }

        private void CreationClientOuMenuPizza(object sender, RoutedEventArgs e)
        {
            tel = NumeroDuClient.Text;

            c1.Tel = tel;

            c2 = c2.DejaClientPizzeria(c1.Tel);

            if (c2 != null)
            {
                MessageBox.Show(c2.ToString());

                MenuPizza m = new MenuPizza(c2);

                m.Show();

                this.Close();
            }
            else
            {
                MessageBox.Show("Le profil n'existe pas");
                
                CreationClient1 c = new CreationClient1();

                c.Show();

                this.Close();
            }
        }
    }
}
