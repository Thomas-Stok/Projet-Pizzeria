﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour Commis.xaml
    /// </summary>
    public partial class Commis : Window
    {
        public Commis()
        {
            InitializeComponent();
        }

        private void NouveauCommis(object sender, RoutedEventArgs e)
        {
            CreationCommis1 c1 = new CreationCommis1();

            c1.Show();
        }

        private void ModifierCommis(object sender, RoutedEventArgs e)
        {
            NomCommis1 n1 = new NomCommis1();

            n1.Show();
        }

        private void ModifierEtatCommis(object sender, RoutedEventArgs e)
        {
            NomCommis3 n3 = new NomCommis3();

            n3.Show();
        }

        private void SupprimerCommis(object sender, RoutedEventArgs e)
        {
            NomCommis2 n2 = new NomCommis2();

            n2.Show();
        }

        private void AfficherCommis(object sender, RoutedEventArgs e)
        {
            AfficherCommis a = new AfficherCommis();

            a.Show();
        }

        private void RetourMenu(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
