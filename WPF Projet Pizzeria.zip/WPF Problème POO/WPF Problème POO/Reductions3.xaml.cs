﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour Reductions3.xaml
    /// </summary>
    public partial class Reductions3 : Window
    {
        ClassePizza c1 = new ClassePizza();
        ClasseBoisson c2 = new ClasseBoisson();

        public Reductions3()
        {
            InitializeComponent();
        }

        private void VersMenuAutre(object sender, RoutedEventArgs e)
        {
            c1.ReducPizza3 = Convert.ToDouble(ReductionPizza3.Text);
            c2.ReducBoisson3 = Convert.ToDouble(ReductionBoisson3.Text);

            this.Close();
        }
    }
}
