﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour CréationClient2.xaml
    /// </summary>
    /// 
    public partial class CreationClient2 : Window
    {
        ClasseClient c1 = new ClasseClient();
        ClasseClient c2 = new ClasseClient();

        public CreationClient2(string nomDeClient)
        {
            InitializeComponent();

            c1 = c1.TrouverClient(nomDeClient);

            NomCreationClient2.Text = c1.Nom;
            PrenomCreationClient2.Text = c1.Prenom;
            RueCreationClient2.Text = c1.AdresseRue;
            VilleCreationClient2.Text = c1.AdresseVille;
            TelephoneCreationClient2.Text = c1.Tel;
        }

        private void VersMenuClient(object sender, RoutedEventArgs e)
        {
            c2.Nom = NomCreationClient2.Text;
            c2.Prenom = PrenomCreationClient2.Text;
            c2.AdresseRue = RueCreationClient2.Text;
            c2.AdresseVille = VilleCreationClient2.Text;
            c2.Tel = TelephoneCreationClient2.Text;
            c2.Date_premiere_commande = c1.Date_premiere_commande;
            c2.NbCommandes = c1.NbCommandes;
            c2.MontantTotal = c1.MontantTotal;

            MessageBox.Show(c2.ToString());

            c2.AjouterClient(c2);

            this.Close();
        }
    }
}
