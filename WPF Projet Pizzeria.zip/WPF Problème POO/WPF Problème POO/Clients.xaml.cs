﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour Clients.xaml
    /// </summary>
    public partial class Clients : Window
    {
        public Clients()
        {
            InitializeComponent();
        }

        private void NouveauClient(object sender, RoutedEventArgs e)
        {
            CreationClient3 c3 = new CreationClient3();

            c3.Show();
        }

        private void ModifierClient(object sender, RoutedEventArgs e)
        {
            NomClient1 n1 = new NomClient1();

            n1.Show();
        }

        private void SupprimerClient(object sender, RoutedEventArgs e)
        {
            NomClient2 n2 = new NomClient2();

            n2.Show();
        }

        private void AfficherClients(object sender, RoutedEventArgs e)
        {
            AfficherClients a = new AfficherClients();

            a.Show();
        }

        private void RetourMenu(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
