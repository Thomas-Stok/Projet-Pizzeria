﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour RecapCommande.xaml
    /// </summary>
    public partial class RecapCommande : Window
    {
        ClasseClient c1 = new ClasseClient();
        ClasseCommis c2 = new ClasseCommis();
        ClasseCommis c3 = new ClasseCommis();

        ClassePizza p = new ClassePizza();
        ClasseBoisson b = new ClasseBoisson();

        List<ClassePizza> pizzas = new List<ClassePizza>();
        List<ClasseBoisson> boissons = new List<ClasseBoisson>();

        double prixPizzas;
        double prixBoissons;
        double prixTotal;
        string prix_total;
        string numCommande;
        string trouvee;

        ClasseCommande commande = new ClasseCommande();

        ClasseLivreur livreurChoisi = new ClasseLivreur();

        public RecapCommande(ClasseClient c1, List<ClassePizza> pizzascommandees, List<ClasseBoisson> boissonscommandees, double prixPizzas, double prixBoissons, string numCommande)
        {
            foreach (ClassePizza p1 in pizzascommandees)
            {
                pizzas.Add(p1);
            }

            foreach (ClasseBoisson b1 in boissonscommandees)
            {
                boissons.Add(b1);
            }

            this.DataContext = this;
            InitializeComponent();

            this.c1 = c1;
            this.prixPizzas = prixPizzas;
            this.prixBoissons = prixBoissons;
            this.numCommande = numCommande;

            list1.ItemsSource = pizzas;
            list2.ItemsSource = boissons;

            livreurChoisi = commande.ChoixLivreur();

            LivreurSelectionne.Text = livreurChoisi.Nom;

            ClasseClient client = new ClasseClient();
            ClasseClient meilleur = client.MeilleurClient();
            ClasseClient deuxiemeMeilleur = client.DeuxiemeMeilleurClient();
            ClasseClient troisiemeMeilleur = client.TroisiemeMeilleurClient();

            if (c1.Tel == meilleur.Tel)
                prixTotal = (prixPizzas - p.RetournerPrix(p.RemiseMeilleurClient)) + (prixBoissons - b.RetournerPrix(b.RemiseMeilleurClient));
            else if (c1.Tel == deuxiemeMeilleur.Tel)
                prixTotal = (prixPizzas - p.RetournerPrix(p.RemiseDeuxiemeMeilleurClient)) + (prixBoissons - b.RetournerPrix(b.RemiseMeilleurClient));
            else if (c1.Tel == troisiemeMeilleur.Tel)
                prixTotal = (prixPizzas - p.RetournerPrix(p.RemiseTroisiemeMeilleurClient)) + (prixBoissons - b.RetournerPrix(b.RemiseMeilleurClient));
            else
                prixTotal = prixPizzas + prixBoissons;

            prix_total = Convert.ToString(prixTotal);

            PrixTotal.Text = prix_total;

            trouvee = livreurChoisi.AdresseTrouvee();

            commande.Prix = prix_total;

            int nb = Convert.ToInt32(livreurChoisi.NbLivraisonsEffectuees);
            nb += 1;
            livreurChoisi.NbLivraisonsEffectuees = Convert.ToString(nb);

            livreurChoisi.ModifierLivreur(livreurChoisi);
        }

        private void ModifierCommande(object sender, RoutedEventArgs e)
        {
            MenuPizza m = new MenuPizza(c1);

            m.Show();

            this.Close();
        }

        private void MessageAdresseTrouvee(object sender, RoutedEventArgs e)
        {
            c2.Nom = NomCommisRecap.Text;

            c3 = c3.TrouverCommis(c2.Nom);

            double m = Convert.ToDouble(c1.MontantTotal);
            m += prixTotal;
            c1.MontantTotal = Convert.ToString(m);

            int cumul = Convert.ToInt32(c1.NbCommandes);
            cumul++;
            c1.NbCommandes = Convert.ToString(cumul);

            c1.AjouterClient(c1);

            if (trouvee == "ok")
            {
                int nbc = Convert.ToInt32(c3.NbCommandesGerees);
                nbc += 1;
                c3.NbCommandesGerees = Convert.ToString(nbc);

                commande.Solde = "ok";

                c3.ModifierCommis(c3);

                commande.CreerCommandeEnPreparation(c1.Tel, c2.Nom, livreurChoisi);

                this.Close();

                MessageBox.Show("Adresse Trouvée \nCommande en préparation \nAller dans le menu commande pour finaliser la commande (numéro : " + numCommande + ")");
            }
            else
            {
                commande.Solde = "perdue";

                commande.CreerCommandeEnPreparation(c1.Tel, c2.Nom, livreurChoisi);

                this.Close();

                MessageBox.Show("L'adresse n'a pas été trouvé \nCommande perdue");
            }
        }

        private void list1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
