﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace WPF_Problème_POO
{
    public class ClasseClient : ClassePersonne, INotifyPropertyChanged
    {
        string date_premiere_commande;
        string nbCommandes;
        string montantTotal;

        public ClasseClient(string nom, string prenom, string adresse_rue, string adresse_ville, string tel, string date_premiere_commande, string nbCommandes, string montantTotal) : base(nom, prenom, adresse_rue, adresse_ville, tel)
        {
            this.date_premiere_commande = date_premiere_commande;
            this.nbCommandes = nbCommandes;
            this.montantTotal = montantTotal;
        }

        public ClasseClient()
        {

        }

        public string Date_premiere_commande
        {
            get { return this.date_premiere_commande; }
            set { this.date_premiere_commande = value; }
        }

        public string NbCommandes
        {
            get { return this.nbCommandes; }
            set { this.nbCommandes = value; }
        }

        public string MontantTotal
        {
            get { return this.montantTotal; }
            set { this.montantTotal = value; }
        }

        public override string ToString()
        {
            return base.ToString() + " - Date de première commande : " + Date_premiere_commande + "\nNombre de commandes : " + NbCommandes + "\nMontant total des commandes : " + MontantTotal;
        }

        public int Compare3(ClasseClient c1, ClasseClient c2)
        {
            return c1.MontantTotal.CompareTo(c2.MontantTotal);
        }

        public void AjouterClient(ClasseClient client)
        {
            StreamWriter fichEcriture = new StreamWriter("Clients.csv", true);
            string ligne = client.Nom + ";" + client.Prenom + ";" + client.AdresseRue + ";" + client.AdresseVille + ";" + client.Tel + ";" + client.Date_premiere_commande + ";" + client.NbCommandes + ";" + client.MontantTotal;
            fichEcriture.WriteLine(ligne);
            fichEcriture.Close();
        }

        public List<ClasseClient> LectureFichier()
        {
            List<ClasseClient> clients = null;
            StreamReader st = null;

            try
            {
                clients = new List<ClasseClient>();
                st = new StreamReader("Clients.csv");
                string line = null;
                while ((line = st.ReadLine()) != null)
                {
                    string[] c = line.Split(';');
                    ClasseClient clientTemp = new ClasseClient(c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7]);
                    clients.Add(clientTemp);
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            { if (st != null) st.Close(); }

            return clients;
        }

        public ClasseClient DejaClientPizzeria(string telephone)
        {
            ClasseClient client = new ClasseClient();
            client = null;
            
            List<ClasseClient> clients = LectureFichier();

            foreach (ClasseClient c in clients)
            {
                if (c.Tel == telephone)
                {
                    client = c;
                }
            }
            /*if(client!= null)
            {
                int cumul = Convert.ToInt32(NbCommandes);
                cumul++;
                NbCommandes = Convert.ToString(cumul);
            }*/
            return client;
        }

        public ClasseClient TrouverClient(string nom)
        {
            ClasseClient client = new ClasseClient();
            client = null;

            List<ClasseClient> clients = LectureFichier();

            foreach (ClasseClient c in clients)
            {
                if (c.Nom == nom)
                {
                    client = c;
                }
            }

            return client;
        }

        public string RetournerTel()
        {
            return tel;
        }

        public ClasseClient MeilleurClient()
        {
            ClasseClient meilleur = new ClasseClient("Bond", "James", "4 rue de Colombes 75001", "Paris", "01", "01/01/2021", "0", "0");

            List<ClasseClient> clients = LectureFichier();

            foreach (ClasseClient c in clients)
            {
                if (double.Parse(c.MontantTotal) > double.Parse(meilleur.MontantTotal))
                {
                    meilleur = c;
                }
            }

            return meilleur;
        }

        public ClasseClient DeuxiemeMeilleurClient()
        {
            ClasseClient meilleur = MeilleurClient();
            ClasseClient deuxiemeMeilleur = new ClasseClient("Bond", "James", "4 rue de Colombes 75001", "Paris", "01", "01/01/2021", "0", "0");

            List<ClasseClient> clients = LectureFichier();

            foreach (ClasseClient c in clients)
            {
                if ((double.Parse(c.MontantTotal) > double.Parse(deuxiemeMeilleur.MontantTotal)) && (double.Parse(c.MontantTotal) < double.Parse(meilleur.MontantTotal)))
                {
                    deuxiemeMeilleur = c;
                }
            }

            return deuxiemeMeilleur;
        }

        public ClasseClient TroisiemeMeilleurClient()
        {
            ClasseClient deuxiemeMeilleur = DeuxiemeMeilleurClient();
            ClasseClient troisiemeMeilleur = new ClasseClient("Bond", "James", "4 rue de Colombes 75001", "Paris", "01", "01/01/2021", "0", "0");

            List<ClasseClient> clients = LectureFichier();

            foreach (ClasseClient c in clients)
            {
                if ((double.Parse(c.MontantTotal) > double.Parse(troisiemeMeilleur.MontantTotal)) && (double.Parse(c.MontantTotal) < double.Parse(deuxiemeMeilleur.MontantTotal)))
                {
                    troisiemeMeilleur = c;
                }
            }

            return troisiemeMeilleur;
        }
    }
}
