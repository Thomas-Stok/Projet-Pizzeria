﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour CreationCommis.xaml
    /// </summary>
    public partial class CreationCommis1 : Window
    {
        ClasseCommis c = new ClasseCommis();

        public CreationCommis1()
        {
            InitializeComponent();
        }

        private void VersMenuCommis(object sender, RoutedEventArgs e)
        {

            c.Nom = NomCreationCommis1.Text;
            c.Prenom = PrenomCreationCommis1.Text;
            c.AdresseRue = RueCreationCommis1.Text;
            c.AdresseVille = VilleCreationCommis1.Text;
            c.Tel = TelephoneCreationCommis1.Text;
            c.Etat = EtatCreationCommis1.Text;
            c.DateEmbauche = DateCreationCommis1.Text;
            c.NbCommandesGerees = "0";

            MessageBox.Show(c.ToString());

            c.ModifierCommis(c);

            this.Close();
        }
    }
}
