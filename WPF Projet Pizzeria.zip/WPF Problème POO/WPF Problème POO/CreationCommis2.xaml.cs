﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour CreationCommis2.xaml
    /// </summary>
    public partial class CreationCommis2 : Window
    {
        ClasseCommis c1 = new ClasseCommis();
        ClasseCommis c2 = new ClasseCommis();

        public CreationCommis2(string nomDeCommis)
        {
            InitializeComponent();

            c1 = c1.TrouverCommis(nomDeCommis);

            NomCreationCommis2.Text = c1.Nom;
            PrenomCreationCommis2.Text = c1.Prenom;
            RueCreationCommis2.Text = c1.AdresseRue;
            VilleCreationCommis2.Text = c1.AdresseVille;
            TelephoneCreationCommis2.Text = c1.Tel;
            EtatCreationCommis2.Text = c1.Etat;
            DateCreationCommis2.Text = c1.DateEmbauche;
        }

        private void VersMenuCommis(object sender, RoutedEventArgs e)
        {
            
            c2.Nom = NomCreationCommis2.Text;
            c2.Prenom = PrenomCreationCommis2.Text;
            c2.AdresseRue = RueCreationCommis2.Text;
            c2.AdresseVille = VilleCreationCommis2.Text;
            c2.Tel = TelephoneCreationCommis2.Text;
            c2.Etat = EtatCreationCommis2.Text;
            c2.DateEmbauche = DateCreationCommis2.Text;
            c2.NbCommandesGerees = c1.NbCommandesGerees;

            MessageBox.Show(c2.ToString());

            c2.ModifierCommis(c2);

            this.Close();
        }
    }
}
