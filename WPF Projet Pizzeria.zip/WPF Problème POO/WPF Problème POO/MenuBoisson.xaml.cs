﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour MenuBoisson.xaml
    /// </summary>
    public partial class MenuBoisson : Window
    {
        ClasseClient c = new ClasseClient();
        ClasseBoisson b1 = new ClasseBoisson();
        ClasseBoisson b2 = new ClasseBoisson();
        ClasseBoisson b3 = new ClasseBoisson();
        ClasseBoisson b4 = new ClasseBoisson();
        ClasseBoisson b5 = new ClasseBoisson();
        ClasseBoisson b6 = new ClasseBoisson();
        ClasseBoisson b7 = new ClasseBoisson();
        ClasseBoisson b8 = new ClasseBoisson();

        List<ClassePizza> pizzascommandees = new List<ClassePizza>();

        double prixPizzas;
        double prix;

        string numCommande;

        public MenuBoisson(ClasseClient c, List<ClassePizza> pizzascommandees, double prixPizzas)
        {
            InitializeComponent();

            this.c = c;
            this.pizzascommandees = pizzascommandees;
            this.prixPizzas = prixPizzas;

            prix = 0;
            numCommande = "X";
        }

        private void VersRecapCommande(object sender, RoutedEventArgs e)
        {
            #region Quantités

            b1.QuantiteEauNaturelle = Convert.ToInt32(QuantiteEauNaturelle.Text);
            b2.QuantiteEauGazeuse = Convert.ToInt32(QuantiteEauGazeuse.Text);
            b3.QuantiteCoca = Convert.ToInt32(QuantiteCoca.Text);
            b4.QuantiteFanta = Convert.ToInt32(QuantiteFanta.Text);
            b5.QuantiteOasis = Convert.ToInt32(QuantiteOasis.Text);
            b6.QuantiteIcetea = Convert.ToInt32(QuantiteIcetea.Text);
            b7.QuantiteSprite = Convert.ToInt32(QuantiteSprite.Text);
            b8.QuantiteBiere = Convert.ToInt32(QuantiteBiere.Text);

            #endregion

            string volumeEauNaturelle = "M";
            string volumeEauGazeuse = "M";
            string volumeCoca = "M";
            string volumeFanta = "M";
            string volumeOasis = "M";
            string volumeIcetea = "M";
            string volumeSprite = "M";
            string volumeBiere = "M";

            #region Volumes

            ComboBoxItem item1 = new ComboBoxItem();
            item1 = (ComboBoxItem)VolumeEauNaturelle.SelectedItem;
            if (item1 != null)
            {
                volumeEauNaturelle = (string)item1.Content;
                b1.VolumeEauNaturelle = volumeEauNaturelle;
            }
            

            ComboBoxItem item2 = new ComboBoxItem();
            item2 = (ComboBoxItem)VolumeEauGazeuse.SelectedItem;
            if (item2 != null)
            {
                volumeEauGazeuse = (string)item2.Content;
                b1.VolumeEauGazeuse = volumeEauGazeuse;
            }
                

            ComboBoxItem item3 = new ComboBoxItem();
            item3 = (ComboBoxItem)VolumeCoca.SelectedItem;
            if (item3 != null)
            {
                volumeCoca = (string)item3.Content;
                b1.VolumeCoca = volumeCoca;
            }
                

            ComboBoxItem item4 = new ComboBoxItem();
            item4 = (ComboBoxItem)VolumeFanta.SelectedItem;
            if (item4 != null)
            {
                volumeFanta = (string)item4.Content;
                b1.VolumeFanta = volumeFanta;
            }
               

            ComboBoxItem item5 = new ComboBoxItem();
            item5 = (ComboBoxItem)VolumeOasis.SelectedItem;
            if (item5 != null)
            {
                volumeOasis = (string)item5.Content;
                b1.VolumeOasis = volumeOasis;
            }
                

            ComboBoxItem item6 = new ComboBoxItem();
            item6 = (ComboBoxItem)VolumeIcetea.SelectedItem;
            if (item6 != null)
            {
                volumeIcetea = (string)item6.Content;
                b1.VolumeIcetea = volumeIcetea;
            }
                

            ComboBoxItem item7 = new ComboBoxItem();
            item7 = (ComboBoxItem)VolumeSprite.SelectedItem;
            if (item7 != null)
            {
                volumeSprite = (string)item7.Content;
                b1.VolumeSprite = volumeSprite;
            }
               

            ComboBoxItem item8 = new ComboBoxItem();
            item8 = (ComboBoxItem)VolumeBiere.SelectedItem;
            if (item8 != null)
            {
                volumeBiere = (string)item8.Content;
                b1.VolumeBiere = volumeBiere;
            }
                

            #endregion

            List<ClasseBoisson> boissoncommande = new List<ClasseBoisson>();

            #region Ajout des boissons à la liste des boissons commandées

            if (b1.QuantiteEauNaturelle != 0)
            {
                b1.CommandeBoisson(volumeEauNaturelle, "Eau Naturelle", QuantiteEauNaturelle.Text);

                boissoncommande.Add(b1);
                prix += Convert.ToDouble(b1.PrixB);
                numCommande = b1.RecupererNumCommande();
            }
            if (b2.QuantiteEauGazeuse != 0)
            {
                b2.CommandeBoisson(volumeEauGazeuse, "Eau Gazeuse", QuantiteEauGazeuse.Text);

                boissoncommande.Add(b2);
                prix += Convert.ToDouble(b2.PrixB);
                numCommande = b2.RecupererNumCommande();
            }
            if (b3.QuantiteCoca != 0)
            {
                b3.CommandeBoisson(volumeCoca, "Coca", QuantiteCoca.Text);

                boissoncommande.Add(b3);
                prix += Convert.ToDouble(b3.PrixB);
                numCommande = b3.RecupererNumCommande();
            }
            if (b4.QuantiteFanta != 0)
            {
                b4.CommandeBoisson(volumeFanta, "Fanta", QuantiteFanta.Text);

                boissoncommande.Add(b4);
                prix += Convert.ToDouble(b4.PrixB);
                numCommande = b4.RecupererNumCommande();
            }
            if (b5.QuantiteOasis != 0)
            {
                b5.CommandeBoisson(volumeOasis, "Oasis", QuantiteOasis.Text);

                boissoncommande.Add(b5);
                prix += Convert.ToDouble(b5.PrixB);
                numCommande = b5.RecupererNumCommande();
            }
            if (b6.QuantiteIcetea != 0)
            {
                b6.CommandeBoisson(volumeIcetea, "Icetea", QuantiteIcetea.Text);

                boissoncommande.Add(b6);
                prix += Convert.ToDouble(b6.PrixB);
                numCommande = b6.RecupererNumCommande();
            }
            if (b7.QuantiteSprite != 0)
            {
                b7.CommandeBoisson(volumeSprite, "Sprite", QuantiteSprite.Text);

                boissoncommande.Add(b7);
                prix += Convert.ToDouble(b7.PrixB);
                numCommande = b7.RecupererNumCommande();
            }
            if (b8.QuantiteBiere != 0)
            {
                b8.CommandeBoisson(volumeBiere, "Biere", QuantiteBiere.Text);

                boissoncommande.Add(b8);
                prix += Convert.ToDouble(b8.PrixB);
                numCommande = b8.RecupererNumCommande();
            }

            #endregion

            RecapCommande r = new RecapCommande(c, pizzascommandees, boissoncommande, prixPizzas, prix, numCommande);

            r.Show();

            this.Close();
        }

        private void VolumeEauNaturelle_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
