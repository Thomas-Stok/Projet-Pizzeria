﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace WPF_Problème_POO
{
    public class ClassePizza : INotifyPropertyChanged
    {
        #region Attributs

        string taille;
        string type;
        string prixP;
        string quantite;

        int quantiteMargherita;
        int quantiteRoyale;
        int quantiteReine;
        int quantiteNapolitaine;
        int quantiteCalzone;
        int quantite4Saisons;
        int quantite4Fromages;
        int quantiteHawaienne;
        int quantiteRaclettte;
        int quantiteDiavola;

        string tailleMargherita;
        string tailleRoyale;
        string tailleReine;
        string tailleNapolitaine;
        string tailleCalzone;
        string taille4Saisons;
        string taille4Fromages;
        string tailleHawaienne;
        string tailleRaclettte;
        string tailleDiavola;

        string numCommande;
        double reducPizza1;
        double reducPizza2;
        double reducPizza3;
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        public ClassePizza()
        {
            #region Intialisation attributs

            this.taille = "";
            this.type = "";
            this.prixP = "0";

            this.quantite = "0";

            this.quantiteMargherita = 0;
            this.quantiteRoyale = 0;
            this.quantiteReine = 0;
            this.quantiteNapolitaine = 0;
            this.quantiteCalzone = 0;
            this.quantite4Saisons = 0;
            this.quantite4Fromages = 0;
            this.quantiteHawaienne = 0;
            this.quantiteRaclettte = 0;
            this.quantiteDiavola = 0;

            this.tailleMargherita = "moyenne";
            this.tailleRoyale = "moyenne";
            this.tailleReine = "moyenne";
            this.tailleNapolitaine = "moyenne";
            this.tailleCalzone = "moyenne";
            this.taille4Saisons = "moyenne";
            this.taille4Fromages = "moyenne";
            this.tailleHawaienne = "moyenne";
            this.tailleRaclettte = "moyenne";
            this.tailleDiavola = "moyenne";

            this.numCommande = "0";
            this.reducPizza1 = 0;
            this.reducPizza2 = 0;
            this.reducPizza3 = 0;

            #endregion
        }

        public ClassePizza(string quantite, string type, string taille)
        {
            this.quantite = quantite;
            this.type = type;
            this.taille = taille;
        }

        public ClassePizza(string taille, string type, string quantite, string prixP)
        {
            this.taille = taille;
            this.type = type;
            this.quantite = quantite;
            this.prixP = prixP;
        }

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        #region Propriétés Quantités

        public int QuantiteMargherita
        {
            get { return this.quantiteMargherita; }
            set { this.quantiteMargherita = value; OnPropertyChanged("QuantiteMargherita"); }
        }

        public int QuantiteRoyale
        {
            get { return this.quantiteRoyale; }
            set { this.quantiteRoyale = value; OnPropertyChanged("QuantiteRoyale"); }
        }

        public int QuantiteReine
        {
            get { return this.quantiteReine; }
            set { this.quantiteReine = value; OnPropertyChanged("QuantiteReine"); }
        }

        public int QuantiteNapolitaine
        {
            get { return this.quantiteNapolitaine; }
            set { this.quantiteNapolitaine = value; OnPropertyChanged("QuantiteNapolitaine"); }
        }

        public int QuantiteCalzone
        {
            get { return this.quantiteCalzone; }
            set { this.quantiteCalzone = value; OnPropertyChanged("QuantiteCalzone"); }
        }

        public int Quantite4Saisons
        {
            get { return this.quantite4Saisons; }
            set { this.quantite4Saisons = value; OnPropertyChanged("Quantite4Saisons"); }
        }

        public int Quantite4Fromages
        {
            get { return this.quantite4Fromages; }
            set { this.quantite4Fromages = value; OnPropertyChanged("Quantite4Fromages"); }
        }

        public int QuantiteHawaienne
        {
            get { return this.quantiteHawaienne; }
            set { this.quantiteHawaienne = value; OnPropertyChanged("QuantiteHawaienne"); }
        }

        public int QuantiteRaclette
        {
            get { return this.quantiteRaclettte; }
            set { this.quantiteRaclettte = value; OnPropertyChanged("QuantiteRaclette"); }
        }

        public int QuantiteDiavola
        {
            get { return this.quantiteDiavola; }
            set { this.quantiteDiavola = value; OnPropertyChanged("QuantiteDiavola"); }
        }

        #endregion

        #region Propriétés Tailles

        public string TailleMargherita
        {
            get { return this.tailleMargherita; }
            set { this.tailleMargherita = value; OnPropertyChanged("TailleMargherita"); }
        }

        public string TailleRoyale
        {
            get { return this.tailleRoyale; }
            set { this.tailleRoyale = value; OnPropertyChanged("TailleRoyale"); }
        }

        public string TailleReine
        {
            get { return this.tailleReine; }
            set { this.tailleReine = value; OnPropertyChanged("TailleReine"); }
        }

        public string TailleNapolitaine
        {
            get { return this.tailleNapolitaine; }
            set { this.tailleNapolitaine = value; OnPropertyChanged("TailleNapolitaine"); }
        }

        public string TailleCalzone
        {
            get { return this.tailleCalzone; }
            set { this.tailleCalzone = value; OnPropertyChanged("TailleCalzone"); }
        }

        public string Taille4Saisons
        {
            get { return this.taille4Saisons; }
            set { this.taille4Saisons = value; OnPropertyChanged("Taille4Saisons"); }
        }

        public string Taille4Fromages
        {
            get { return this.taille4Fromages; }
            set { this.taille4Fromages = value; OnPropertyChanged("Taille4Fromages"); }
        }

        public string TailleHawaienne
        {
            get { return this.tailleHawaienne; }
            set { this.tailleHawaienne = value; OnPropertyChanged("TailleHawaienne"); }
        }

        public string TailleRaclette
        {
            get { return this.tailleRaclettte; }
            set { this.tailleRaclettte = value; OnPropertyChanged("TailleRaclette"); }
        }

        public string TailleDiavola
        {
            get { return this.tailleDiavola; }
            set { this.tailleDiavola = value; OnPropertyChanged("TailleDiavola"); }
        }

        #endregion

        public string Taille
        {
            get { return this.taille; }
            set { this.taille = value; OnPropertyChanged("Taille"); }
        }

        public string Type
        {
            get { return this.type; }
            set { this.type = value; OnPropertyChanged("Type"); }
        }

        public string Quantite
        {
            get { return this.quantite; }
            set { this.quantite = value; OnPropertyChanged("Quantite"); }
        }

        public string Prix
        {
            get { return this.prixP; }
            set { this.prixP = value; }
        }

        public string NumCommande
        {
            set { this.numCommande = value; }
            get { return this.numCommande; }
        }

        public double ReducPizza1
        {
            get { return this.reducPizza1; }
            set { this.reducPizza1 = value; OnPropertyChanged("ReducPizza1"); }
        }

        public double ReducPizza2
        {
            get { return this.reducPizza2; }
            set { this.reducPizza2 = value; OnPropertyChanged("ReducPizza2"); }
        }

        public double ReducPizza3
        {
            get { return this.reducPizza3; }
            set { this.reducPizza3 = value; OnPropertyChanged("ReducPizza3"); }
        }

        public override string ToString()
        {
            return Type + " " + Taille + " " + Quantite;
        }

        public void LectureFichier()
        {
            StreamReader st = null;

            int num = 0;

            try
            {
                st = new StreamReader("Commandes.csv");
                string line = null;
                while ((line = st.ReadLine()) != null)
                {
                    string[] c = line.Split(';');
                    ClasseCommande commandeTemp = new ClasseCommande(c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7]);
                    num = Convert.ToInt32(c[0]);
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            { if (st != null) st.Close(); }

            NumCommande = Convert.ToString(num + 1);
        }

        public void AjouterDetailsCommande(ClassePizza pizza)
        {
            StreamWriter fichEcriture = new StreamWriter("DetailsCommandes.csv", true);
            string ligne = NumCommande + ";" + "Pizza" + ";" + PrixPizza(pizza.Type, pizza.Taille) + ";" + pizza.Type + ";" + pizza.Taille + ";" + " " + ";" + pizza.Quantite;
            fichEcriture.WriteLine(ligne);
            fichEcriture.Close();
        }

        public double PrixPizza(string type, string taille)
        {
            int pizza_8 = 8;
            int pizza_9 = 9;
            double pizza_9_5 = 9.5;
            int pizza_11 = 11;

            double prix = 0;

            if (type == "Margherita")
                prix = pizza_8;
            if (type == "Royale" || type == "Reine" || type == "Napolitaine" || type == "Calzone")
                prix = pizza_9;
            if (type == "4 Saisons")
                prix = pizza_9_5;
            if (type == "4 Fromages" || type == "Hawaienne" || type == "Raclette" || type == "Diavola")
                prix = pizza_11;

            if (taille == "Petite")
                prix--;
            else if (taille == "Grande")
                prix += 2;

            return prix;
        }

        public ClassePizza CommandePizza(string taille, string type, string quantite)
        {
            LectureFichier();
            double prix = 0;

            Taille = taille;
            Type = type;
            Quantite = quantite;

            int quant = Convert.ToInt32(quantite);
            prix += PrixPizza(type, taille)*quant;
            ClassePizza p = new ClassePizza(taille, type, quantite, Convert.ToString(prix));

            AjouterDetailsCommande(p);
            
            prixP = Convert.ToString(prix);

            return p;
        }

        public delegate double RemiseMeilleursClients();

        public double RemiseMeilleurClient()
        {
            return ReducPizza1;
        }

        public double RemiseDeuxiemeMeilleurClient()
        {
            return ReducPizza2;
        }

        public double RemiseTroisiemeMeilleurClient()
        {
            return ReducPizza3;
        }

        public double RetournerPrix(RemiseMeilleursClients remise)
        {
            return remise();
        }
    }
}
