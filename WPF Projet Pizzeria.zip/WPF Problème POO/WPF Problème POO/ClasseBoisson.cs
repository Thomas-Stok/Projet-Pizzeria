﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.ComponentModel;

namespace WPF_Problème_POO
{
    public class ClasseBoisson : INotifyPropertyChanged
    {
        #region Attributs

        string nom;
        string volume;
        string quantite;
        string prixB;

        int quantiteEauNaturelle;
        int quantiteEauGazeuse;
        int quantiteCoca;
        int quantiteFanta;
        int quantiteOasis;
        int quantiteIcetea;
        int quantiteSprite;
        int quantiteBiere;

        string volumeEauNaturelle;
        string volumeEauGazeuse;
        string volumeCoca;
        string volumeFanta;
        string volumeOasis;
        string volumeIcetea;
        string volumeSprite;
        string volumeBiere;

        string numCommande;
        double reducBoisson1;
        double reducBoisson2;
        double reducBoisson3;
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        public ClasseBoisson()
        {
            #region Initialisation attributs

            this.nom = "";
            this.volume = "";
            this.quantite = "0";
            this.prixB = "0";

            this.quantiteEauNaturelle = 0;
            this.quantiteEauGazeuse = 0;
            this.quantiteCoca = 0;
            this.quantiteFanta = 0;
            this.quantiteOasis = 0;
            this.quantiteIcetea = 0;
            this.quantiteSprite = 0;
            this.quantiteBiere = 0;

            this.volumeEauNaturelle = "M";
            this.volumeEauGazeuse = "M";
            this.volumeCoca = "M";
            this.volumeFanta = "M";
            this.volumeOasis = "M";
            this.volumeIcetea = "M";
            this.volumeSprite = "M";
            this.volumeBiere = "M";

            this.numCommande = "0";
            this.reducBoisson1 = 0;
            this.reducBoisson2 = 0;
            this.reducBoisson3 = 0;

            #endregion
        }

        public ClasseBoisson(string quantite, string nom, string volume)
        {
            this.quantite = quantite; 
            this.nom = nom;
            this.volume = volume;
        }

        public ClasseBoisson(string nom, string volume, string quantite, string prixB)
        {
            this.nom = nom;
            this.volume = volume;
            this.quantite = quantite;
            this.prixB = prixB;
        }

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        #region Propriétés Quantités

        public int QuantiteEauNaturelle
        {
            get { return this.quantiteEauNaturelle; }
            set { this.quantiteEauNaturelle = value; OnPropertyChanged("QuantiteEauNaturelle"); }
        }

        public int QuantiteEauGazeuse
        {
            get { return this.quantiteEauGazeuse; }
            set { this.quantiteEauGazeuse = value; OnPropertyChanged("QuantiteEauGazeuse"); }
        }

        public int QuantiteCoca
        {
            get { return this.quantiteCoca; }
            set { this.quantiteCoca = value; OnPropertyChanged("QuantiteCoca"); }
        }

        public int QuantiteFanta
        {
            get { return this.quantiteFanta; }
            set { this.quantiteFanta = value; OnPropertyChanged("QuantiteFanta"); }
        }

        public int QuantiteOasis
        {
            get { return this.quantiteOasis; }
            set { this.quantiteOasis = value; OnPropertyChanged("QuantiteOasis"); }
        }

        public int QuantiteIcetea
        {
            get { return this.quantiteIcetea; }
            set { this.quantiteIcetea = value; OnPropertyChanged("QuantiteIcetea"); }
        }

        public int QuantiteSprite
        {
            get { return this.quantiteSprite; }
            set { this.quantiteSprite = value; OnPropertyChanged("QuantiteSprite"); }
        }

        public int QuantiteBiere
        {
            get { return this.quantiteBiere; }
            set { this.quantiteBiere = value; OnPropertyChanged("QuantiteBiere"); }
        }

        #endregion

        #region Propriétés Volumes

        public string VolumeEauNaturelle
        {
            get { return this.volumeEauNaturelle; }
            set { this.volumeEauNaturelle = value; OnPropertyChanged("VolumeEauNaturelle"); }
        }

        public string VolumeEauGazeuse
        {
            get { return this.volumeEauGazeuse; }
            set { this.volumeEauGazeuse = value; OnPropertyChanged("VolumeEauGazeuse"); }
        }

        public string VolumeCoca
        {
            get { return this.volumeCoca; }
            set { this.volumeCoca = value; OnPropertyChanged("VolumeCoca"); }
        }

        public string VolumeFanta
        {
            get { return this.volumeFanta; }
            set { this.volumeFanta = value; OnPropertyChanged("VolumeFanta"); }
        }

        public string VolumeOasis
        {
            get { return this.volumeOasis; }
            set { this.volumeOasis = value; OnPropertyChanged("VolumeOasis"); }
        }

        public string VolumeIcetea
        {
            get { return this.volumeIcetea; }
            set { this.volumeIcetea = value; OnPropertyChanged("VolumeIcetea"); }
        }

        public string VolumeSprite
        {
            get { return this.volumeSprite; }
            set { this.volumeSprite = value; OnPropertyChanged("VolumeSprite"); }
        }

        public string VolumeBiere
        {
            get { return this.volumeBiere; }
            set { this.volumeBiere = value; OnPropertyChanged("VolumeBiere"); }
        }

        #endregion

        public string Nom
        {
            get { return this.nom; }
            set { this.nom = value; OnPropertyChanged("Nom"); }
        }

        public string Volume
        {
            get { return this.volume; }
            set { this.volume = value; OnPropertyChanged("Volume"); }
        }

        public string Quantite
        {
            get { return this.quantite; }
            set { this.quantite = value; OnPropertyChanged("Quantite"); }
        }

        public string PrixB
        {
            get { return this.prixB; }
            set { this.prixB = value; }
        }

        public string NumCommande
        {
            set { this.numCommande = value; }
            get { return this.numCommande; }
        }

        public double ReducBoisson1
        {
            get { return this.reducBoisson1; }
            set { this.reducBoisson1 = value; OnPropertyChanged("ReducBoisson1"); }
        }

        public double ReducBoisson2
        {
            get { return this.reducBoisson2; }
            set { this.reducBoisson2 = value; OnPropertyChanged("ReducBoisson2"); }
        }

        public double ReducBoisson3
        {
            get { return this.reducBoisson3; }
            set { this.reducBoisson3 = value; OnPropertyChanged("ReducBoisson3"); }
        }

        public override string ToString()
        {
            return Nom + " " + Volume + " " + Quantite;
        }

        public void LectureFichier()
        {
            StreamReader st = null;

            int num = 0;

            try
            {
                st = new StreamReader("Commandes.csv");
                string line = null;
                while ((line = st.ReadLine()) != null)
                {
                    string[] c = line.Split(';');
                    ClasseCommande commandeTemp = new ClasseCommande(c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7]);
                    num = Convert.ToInt32(c[0]);
                }
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            { if (st != null) st.Close(); }

            NumCommande = Convert.ToString(num + 1);
        }

        public string RecupererNumCommande()
        {
            return NumCommande;
        }

        public void AjouterDetailsCommande(ClasseBoisson boisson)
        {
            StreamWriter fichEcriture = new StreamWriter("DetailsCommandes.csv", true);
            string ligne = NumCommande + ";" + "Boisson" + ";" + PrixBoisson(boisson.Nom, boisson.Volume) + ";" + boisson.Nom + ";" + " " + ";" + boisson.Volume + ";" + boisson.Quantite;
            fichEcriture.WriteLine(ligne);
            fichEcriture.Close();
        }

        public double PrixBoisson(string nom, string volume)
        {
            int boisson_2 = 2;
            double boisson_2_5 = 2.5;
            int boisson_3 = 3;
            int boisson_4 = 4;

            double prix = 0;

            if (nom == "Eau Naturelle")
                prix = boisson_2;
            if (nom == "Eau Gazeuse")
                prix = boisson_2_5;
            if (nom == "Coca" || nom == "Fanta" || nom == "Oasis" || nom == "Icetea" || nom == "Sprite")
                prix = boisson_3;
            if (nom == "Biere")
                prix = boisson_4;

            if (volume == "S")
                prix--;
            else if (volume == "L")
                prix++;

            return prix;
        }

        public ClasseBoisson CommandeBoisson(string nom, string volume, string quantite)
        {
            LectureFichier();
            double prix = 0;

            Nom = nom;
            Volume = volume;
            Quantite = quantite;

            int quant = Convert.ToInt32(quantite);
            prix += PrixBoisson(nom, volume)*quant;
            ClasseBoisson b = new ClasseBoisson(nom, volume, quantite, Convert.ToString(prix));

            AjouterDetailsCommande(b);
            
            prixB = Convert.ToString(prix);

            return b;
        }

        public delegate double RemiseMeilleursClients();

        public double RemiseMeilleurClient()
        {
            return ReducBoisson1;
        }

        public double RemiseDeuxiemeMeilleurClient()
        {
            return ReducBoisson2;
        }

        public double RemiseTroisiemeMeilleurClient()
        {
            return ReducBoisson3;
        }

        public double RetournerPrix(RemiseMeilleursClients remise)
        {
            return remise();
        }
    }
}
