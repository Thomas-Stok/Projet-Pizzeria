﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour AfficherClients.xaml
    /// </summary>
    public partial class AfficherClients : Window
    {
        string affichage = "";

        ClasseClient c;

        public AfficherClients()
        {
            InitializeComponent();
        }

        private void AfficherLesClients(object sender, RoutedEventArgs e)
        {
            this.Close();

            if (RadioButton1Client.IsChecked == true)
            {
                ClasseClient client1 = new ClasseClient();

                List<ClasseClient> clients1 = new List<ClasseClient>();
                clients1 = client1.LectureFichier();

                clients1.Sort(client1.Compare);
                clients1.ForEach(x => affichage += x.ToString() + "\n");

                MessageBox.Show(affichage);
            }
            else if (RadioButton2Client.IsChecked == true)
            {
                ClasseClient client2 = new ClasseClient();

                List<ClasseClient> clients2 = new List<ClasseClient>();
                clients2 = client2.LectureFichier();

                clients2.Sort(client2.Compare2);
                clients2.ForEach(x => affichage += x.ToString() + "\n");

                MessageBox.Show(affichage);
            }
            else if (RadioButton3Client.IsChecked == true)
            {
                ClasseClient client3 = new ClasseClient();

                List<ClasseClient> clients3 = new List<ClasseClient>();
                clients3 = client3.LectureFichier();

                clients3.Sort(client3.Compare3);
                clients3.ForEach(x => affichage += x.ToString() + "\n");

                MessageBox.Show(affichage);
            }
        }
    }
}
