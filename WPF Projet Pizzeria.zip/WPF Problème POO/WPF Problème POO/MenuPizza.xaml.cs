﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour MenuPizza.xaml
    /// </summary>
    public partial class MenuPizza : Window
    {
        ClasseClient c = new ClasseClient();
        ClassePizza p1 = new ClassePizza();
        ClassePizza p2 = new ClassePizza();
        ClassePizza p3 = new ClassePizza();
        ClassePizza p4 = new ClassePizza();
        ClassePizza p5 = new ClassePizza();
        ClassePizza p6 = new ClassePizza();
        ClassePizza p7 = new ClassePizza();
        ClassePizza p8 = new ClassePizza();
        ClassePizza p9 = new ClassePizza();
        ClassePizza p10 = new ClassePizza();

        double prix;

        public MenuPizza(ClasseClient c)
        {
            InitializeComponent();

            this.c = c;

            prix = 0;
        }

        private void VersMenuBoisson(object sender, RoutedEventArgs e)
        {
            #region Quantité

            p1.QuantiteMargherita = Convert.ToInt32(QuantiteMargherita.Text);
            p2.QuantiteRoyale = Convert.ToInt32(QuantiteRoyale.Text);
            p3.QuantiteReine = Convert.ToInt32(QuantiteReine.Text);
            p4.QuantiteNapolitaine = Convert.ToInt32(QuantiteNapolitaine.Text);
            p5.QuantiteCalzone = Convert.ToInt32(QuantiteCalzone.Text);
            p6.Quantite4Saisons = Convert.ToInt32(Quantite4Saisons.Text);
            p7.Quantite4Fromages = Convert.ToInt32(Quantite4Fromages.Text);
            p8.QuantiteHawaienne = Convert.ToInt32(QuantiteHawaienne.Text);
            p9.QuantiteRaclette = Convert.ToInt32(QuantiteRaclette.Text);
            p10.QuantiteDiavola = Convert.ToInt32(QuantiteDiavola.Text);

            #endregion

            #region Taille

            string tailleMargherita = "Moyenne";
            string tailleRoyale = "Moyenne";
            string tailleReine = "Moyenne";
            string tailleNapolitaine = "Moyenne";
            string tailleCalzone = "Moyenne";
            string taille4Saisons = "Moyenne";
            string taille4Fromages = "Moyenne";
            string tailleHawaienne = "Moyenne";
            string tailleRaclette = "Moyenne";
            string tailleDiavola = "Moyenne";

            ComboBoxItem item1 = new ComboBoxItem();
            item1 = (ComboBoxItem)TailleMargherita.SelectedItem;
            
            if (item1 != null)
            {
                tailleMargherita = (string)item1.Content;
                p1.TailleMargherita = tailleMargherita;
            }
                
            ComboBoxItem item2 = new ComboBoxItem();
            item2 = (ComboBoxItem)TailleRoyale.SelectedItem;
            if (item2 != null)
            {
                tailleRoyale = (string)item2.Content;
                p2.TailleRoyale = tailleRoyale;
            }

                
            ComboBoxItem item3 = new ComboBoxItem();
            item3 = (ComboBoxItem)TailleReine.SelectedItem;
            if (item3 != null)
            {
                tailleReine = (string)item3.Content;
                p3.TailleReine = tailleReine;
            }
                

            ComboBoxItem item4 = new ComboBoxItem();
            item4 = (ComboBoxItem)TailleNapolitaine.SelectedItem;
            if (item4 != null)
            {
                tailleNapolitaine = (string)item4.Content;
                p4.TailleNapolitaine = tailleNapolitaine;
            }

            ComboBoxItem item5 = new ComboBoxItem();
            item5 = (ComboBoxItem)TailleCalzone.SelectedItem;
            if (item5 != null)
            {
                tailleCalzone = (string)item5.Content;
                p5.TailleCalzone = tailleCalzone;
            }
                

            ComboBoxItem item6 = new ComboBoxItem();
            item6 = (ComboBoxItem)Taille4Saisons.SelectedItem;
            if (item6 != null)
            {
                taille4Saisons = (string)item6.Content;
                p6.Taille4Saisons = taille4Saisons;
            }
                

            ComboBoxItem item7 = new ComboBoxItem();
            item7 = (ComboBoxItem)Taille4Fromages.SelectedItem;
            if (item7 != null)
            {
                taille4Fromages = (string)item7.Content;
                p7.Taille4Fromages = taille4Fromages;
            }
                

            ComboBoxItem item8 = new ComboBoxItem();
            item8 = (ComboBoxItem)TailleHawaienne.SelectedItem;
            if (item8 != null)
            {
                tailleHawaienne = (string)item8.Content;
                p8.TailleHawaienne = tailleHawaienne;
            }
                

            ComboBoxItem item9 = new ComboBoxItem();
            item9 = (ComboBoxItem)TailleRaclette.SelectedItem;
            if (item9 != null)
            {
                tailleRaclette = (string)item9.Content;
                p9.TailleRaclette = tailleRaclette;
            }
                

            ComboBoxItem item10 = new ComboBoxItem();
            item10 = (ComboBoxItem)TailleDiavola.SelectedItem;
            if (item10 != null)
            {
                tailleDiavola = (string)item10.Content;
                p10.TailleDiavola = tailleDiavola;
            }
                

            #endregion

            List<ClassePizza> pizzacommande = new List<ClassePizza>();

            #region Ajout des pizzas à la liste des pizzas commandées

            if (p1.QuantiteMargherita != 0)
            {
                p1.CommandePizza(tailleMargherita, "Margherita", QuantiteMargherita.Text);

                pizzacommande.Add(p1);
                prix += Convert.ToDouble(p1.Prix);
            }
            if (p2.QuantiteRoyale != 0)
            {
                p2.CommandePizza(tailleRoyale, "Royale", QuantiteRoyale.Text);

                pizzacommande.Add(p2);
                prix += Convert.ToDouble(p2.Prix);
            }
            if (p3.QuantiteReine != 0)
            {
                p3.CommandePizza(tailleReine, "Reine", QuantiteReine.Text);

                pizzacommande.Add(p3);
                prix += Convert.ToDouble(p3.Prix);
            }
            if (p4.QuantiteNapolitaine != 0)
            {
                p4.CommandePizza(tailleNapolitaine, "Napolitaine", QuantiteNapolitaine.Text);

                pizzacommande.Add(p4);
                prix += Convert.ToDouble(p4.Prix);
            }
            if (p5.QuantiteCalzone != 0)
            {
                p5.CommandePizza(tailleCalzone, "Calzone", QuantiteCalzone.Text);

                pizzacommande.Add(p5);
                prix += Convert.ToDouble(p5.Prix);
            }
            if (p6.Quantite4Saisons != 0)
            {
                p6.CommandePizza(taille4Saisons, "4 Saisons", Quantite4Saisons.Text);

                pizzacommande.Add(p6);
                prix += Convert.ToDouble(p6.Prix);
            }
            if (p7.Quantite4Fromages != 0)
            {
                p7.CommandePizza(taille4Fromages, "4 Fromages", Quantite4Fromages.Text);

                pizzacommande.Add(p7);
                prix += Convert.ToDouble(p7.Prix);
            }
            if (p8.QuantiteHawaienne != 0)
            {
                p8.CommandePizza(tailleHawaienne, "Hawaienne", QuantiteHawaienne.Text);

                pizzacommande.Add(p8);
                prix += Convert.ToDouble(p8.Prix);
            }
            if (p9.QuantiteRaclette != 0)
            {
                p9.CommandePizza(tailleRaclette, "Raclette", QuantiteRaclette.Text);

                pizzacommande.Add(p9);
                prix += Convert.ToDouble(p9.Prix);
            }
            if (p10.QuantiteDiavola != 0)
            {
                p10.CommandePizza(tailleDiavola, "Diavola", QuantiteDiavola.Text);

                pizzacommande.Add(p10);
                prix += Convert.ToDouble(p10.Prix);
            }

            #endregion

            MenuBoisson m = new MenuBoisson(c, pizzacommande, prix);

            m.Show();

            this.Close();
        }
    }
}
