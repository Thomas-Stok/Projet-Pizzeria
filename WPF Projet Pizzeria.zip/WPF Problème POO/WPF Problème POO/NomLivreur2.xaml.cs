﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour NomLivreur2.xaml
    /// </summary>
    public partial class NomLivreur2 : Window
    {
        ClasseLivreur c1 = new ClasseLivreur();
        ClasseLivreur c2 = new ClasseLivreur();

        public NomLivreur2()
        {
            InitializeComponent();
        }

        private void SupprimerLivreur(object sender, RoutedEventArgs e)
        {
            c1.Nom = NomDuLivreur2.Text;

            c2 = c2.TrouverLivreur(c1.Nom);
            
            this.Close();

            if (c2 != null)
            {
                MessageBox.Show("Livreur Supprimé");
            }
        }
    }
}
