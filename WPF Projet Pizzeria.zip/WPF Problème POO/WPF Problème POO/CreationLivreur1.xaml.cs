﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour CreationLivreur.xaml
    /// </summary>
    public partial class CreationLivreur1 : Window
    {
        ClasseLivreur c = new ClasseLivreur();

        public CreationLivreur1()
        {
            InitializeComponent();
        }

        private void VersMenuLivreur(object sender, RoutedEventArgs e)
        {
            c.Nom = NomCreationLivreur1.Text;
            c.Prenom = PrenomCreationLivreur1.Text;
            c.AdresseRue = RueCreationLivreur1.Text;
            c.AdresseVille = VilleCreationLivreur1.Text;
            c.Tel = TelephoneCreationLivreur1.Text;
            c.Etat = EtatCreationLivreur1.Text;
            c.MoyenTransport = TransportCreationLivreur1.Text;
            c.NbLivraisonsEffectuees = "0";

            MessageBox.Show(c.ToString());

            c.ModifierLivreur(c);

            this.Close();
        }
    }
}
