﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour CréationClient.xaml
    /// </summary>
    public partial class CreationClient1 : Window
    {
        ClasseClient c = new ClasseClient();

        public CreationClient1()
        {
            InitializeComponent();
        }

        private void VersMenuPizza(object sender, RoutedEventArgs e)
        {
            c.Nom = NomCreationClient1.Text;
            c.Prenom = PrenomCreationClient1.Text;
            c.AdresseRue = RueCreationClient1.Text;
            c.AdresseVille = VilleCreationClient1.Text;
            c.Tel = TelephoneCreationClient1.Text;
            c.Date_premiere_commande = DateTime.Today.ToShortDateString();
            c.NbCommandes = "0";
            c.MontantTotal = "0";

            MessageBox.Show(c.ToString());

            //c.AjouterClient(c);
            
            MenuPizza m = new MenuPizza(c);

            m.Show();

            this.Close();
        }

        private void NomCreationClient1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
