﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour Commandes.xaml
    /// </summary>
    public partial class Commandes : Window
    {
        public Commandes()
        {
            InitializeComponent();
        }

        private void AfficherCommande(object sender, RoutedEventArgs e)
        {
            NumeroCommande1 n1 = new NumeroCommande1();

            n1.Show();
        }

        private void PrixCommande(object sender, RoutedEventArgs e)
        {
            NumeroCommande2 n2 = new NumeroCommande2();

            n2.Show();
        }

        private void EtatCommande(object sender, RoutedEventArgs e)
        {
            NumeroCommande3 n3 = new NumeroCommande3();

            n3.Show();
        }

        private void FinaliserCommande(object sender, RoutedEventArgs e)
        {
            NumeroCommande4 n4 = new NumeroCommande4();

            n4.Show();
        }

        private void RetourMenu(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
