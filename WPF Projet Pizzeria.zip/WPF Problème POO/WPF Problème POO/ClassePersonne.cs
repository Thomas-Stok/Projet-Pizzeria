﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace WPF_Problème_POO
{
    public abstract class ClassePersonne : INotifyPropertyChanged
    {
        protected string nom;
        protected string prenom;
        protected string adresse_rue;
        protected string adresse_ville;
        protected string tel;
        public event PropertyChangedEventHandler PropertyChanged;

        public ClassePersonne(string nom, string prenom, string adresse_rue, string adresse_ville, string tel)
        {
            this.nom = nom;
            this.prenom = prenom;
            this.adresse_rue = adresse_rue;
            this.adresse_ville = adresse_ville;
            this.tel = tel;
        }

        public ClassePersonne()
        {

        }

        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        public string Nom
        {
            get { return this.nom; }
            set { this.nom = value; OnPropertyChanged("Nom"); }
        }

        public string Prenom
        {
            get { return this.prenom; }
            set { this.prenom = value; OnPropertyChanged("Prenom"); }
        }

        public string AdresseRue
        {
            get { return this.adresse_rue; }
            set { this.adresse_rue = value; OnPropertyChanged("Adresse_Rue"); }
        }

        public string AdresseVille
        {
            get { return this.adresse_ville; }
            set { this.adresse_ville = value; OnPropertyChanged("Adresse_Ville"); }
        }

        public string Tel
        {
            get { return this.tel; }
            set { this.tel = value; OnPropertyChanged("Tel"); }
        }

        public override string ToString()
        {
            return "Nom : " + Nom + " - Prénom : " + Prenom + " - Adresse : " + AdresseRue + " " + AdresseVille + " - Téléphone : " + Tel;
        }

        public int Compare(ClasseClient c1, ClasseClient c2)
        {
            return c1.Nom.CompareTo(c2.Nom);
        }

        public int Compare2(ClasseClient c1, ClasseClient c2)
        {
            return c1.AdresseVille.CompareTo(c2.AdresseVille);
        }

        public int Compare(ClasseCommis c1, ClasseCommis c2)
        {
            return c1.Nom.CompareTo(c2.Nom);
        }

        public int Compare2(ClasseCommis c1, ClasseCommis c2)
        {
            return c1.AdresseVille.CompareTo(c2.AdresseVille);
        }

        public int Compare(ClasseLivreur c1, ClasseLivreur c2)
        {
            return c1.Nom.CompareTo(c2.Nom);
        }

        public int Compare2(ClasseLivreur c1, ClasseLivreur c2)
        {
            return c1.AdresseVille.CompareTo(c2.AdresseVille);
        }
    }
}
