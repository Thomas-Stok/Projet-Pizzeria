﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour Autre.xaml
    /// </summary>
    public partial class Autre : Window
    {
        public Autre()
        {
            InitializeComponent();
        }

        private void MeilleurClient(object sender, RoutedEventArgs e)
        {
            Reductions1 r1 = new Reductions1();

            r1.Show();
        }

        private void DeuxiemeMeilleurClient(object sender, RoutedEventArgs e)
        {
            Reductions2 r2 = new Reductions2();

            r2.Show();
        }

        private void TroisiemeMeilleurClient(object sender, RoutedEventArgs e)
        {
            Reductions3 r3 = new Reductions3();

            r3.Show();
        }

        private void RetourMenu(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
