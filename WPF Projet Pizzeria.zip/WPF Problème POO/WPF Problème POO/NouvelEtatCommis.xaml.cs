﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour NouvelEtatCommis.xaml
    /// </summary>
    public partial class NouvelEtatCommis : Window
    {
        ClasseCommis c = new ClasseCommis();

        public NouvelEtatCommis(ClasseCommis c)
        {
            InitializeComponent();

            this.c = c;
        }

        private void EtatChange(object sender, RoutedEventArgs e)
        {
            c.Etat = EtatCommis.Text;

            this.Close();
            
            MessageBox.Show("Etat du commis changé");
        }
    }
}
