﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour CommandesPeriode.xaml
    /// </summary>
    public partial class CommandesPeriode : Window
    {
        public CommandesPeriode()
        {
            InitializeComponent();
        }

        private void AfficherCommandesPeriodeTemps(object sender, RoutedEventArgs e)
        {
            this.Close();
            
            MessageBox.Show("2 - 2 Margherita Petite - 1 Bière S \n3 - 1 Reine Petite - 2 Eau Naturelle L \n3 - 2 Raclette Grande", "Liste des commandes");
        }
    }
}
