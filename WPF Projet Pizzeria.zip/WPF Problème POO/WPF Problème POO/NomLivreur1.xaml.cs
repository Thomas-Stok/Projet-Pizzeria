﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Problème_POO
{
    /// <summary>
    /// Logique d'interaction pour NomLivreur.xaml
    /// </summary>
    public partial class NomLivreur1 : Window
    {
        ClasseLivreur c1 = new ClasseLivreur();
        ClasseLivreur c2 = new ClasseLivreur();

        public NomLivreur1()
        {
            InitializeComponent();
        }

        private void NouvelEtat(object sender, RoutedEventArgs e)
        {
            c1.Nom = NomDuLivreur1.Text;

            c2 = c2.TrouverLivreur(c1.Nom);

            if (c2 != null)
            {
                CreationLivreur2 n = new CreationLivreur2(c1.Nom);

                n.Show();
            }

            this.Close();
        }
    }
}
